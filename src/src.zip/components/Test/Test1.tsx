import React from 'react'

type Props = {}

const Test1 = (props: Props) => {
  return (
    <div>Test1</div>
  )
}

export default Test1