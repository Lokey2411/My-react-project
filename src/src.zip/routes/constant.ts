export const ROOT = "/";
export const ABOUT_PATH = "/about";
export const INTRODUCTION_PATH = "/introduction";
export const ENVENT_PATH = "/event";
export const PRODUCT_PATH = "/product";
export const BLOG_PATH = "/blog";
