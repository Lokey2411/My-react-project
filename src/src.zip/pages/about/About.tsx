import React from 'react'

type Props = {}

const About = (props: Props) => {
  return (
    <div>About</div>
  )
}

export default About