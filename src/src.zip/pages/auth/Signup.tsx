import React from 'react'

type Props = {}

const Signup = (props: Props) => {
  return (
    <div>Signup</div>
  )
}

export default Signup