import React from 'react'

type Props = {}

const Login = (props: Props) => {
  return (
    <div>Login</div>
  )
}

export default Login